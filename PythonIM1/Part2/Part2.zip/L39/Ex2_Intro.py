import tkinter
window = tkinter.Tk()

label = tkinter.Label(text="Hello World!")
label.pack()

window.mainloop()