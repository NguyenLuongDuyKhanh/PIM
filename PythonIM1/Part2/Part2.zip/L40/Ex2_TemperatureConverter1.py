import tkinter

window = tkinter.Tk()
window.title("Temperature Converter")
window.resizable(width=False, height=False)

frm_entry = tkinter.Frame(master=window)

# Run the application
window.mainloop()